<?php
/**
 * Mail English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'Неабходна прадаставіць адрас электроннай пошты для адпраўкі.';
$_lang['mail_err_derive_getmailer'] = 'Адбылася спроба выкліку абстрактнага метаду _getMailer() у класе modMail. Вы павінны перавызначыць гэты метад у спадчынным класе.';
$_lang['mail_err_attr_nv'] = '[[+attr]] не з\'яўляецца дапушчальным атрыбутам PHPMailer і будзе ігнаравацца сістэмай.';
$_lang['mail_err_unset_spec'] = 'Клас modPHPMailer не падтрымлівае выдаленне адмысловых адрасоў. Выкарыстоўвайце метад reset() для ачысткі ўсіх атрымальнікаў і пасля гэтага дадайце патрэбных атрымальнікаў зноў.';