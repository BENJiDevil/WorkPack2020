<?php
/**
 * Welcome English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['modx_news'] = 'Навіны MODX';
$_lang['security_notices'] = 'Заўвагі па бяспецы';
$_lang['welcome_messages'] = 'Ваша скрыня змяшчае <strong>%d</ strong> паведамленне(яў), з якіх <strong>%s</ strong> не прачытана.';
$_lang['welcome_title'] = 'Сардэчна запрашаем у Мэнэджэр змесцiва MODX';
$_lang['yourinfo_message'] = 'Гэты раздзел паказвае некаторыя звесткі аб вас:';
$_lang['yourinfo_previous_login'] = 'Ваш апошні уваход:';
$_lang['yourinfo_title'] = 'Ваша інфармацыя';
$_lang['yourinfo_total_logins'] = 'Агульная колькасць уваходаў:';
$_lang['yourinfo_username'] = 'Вы ўвайшлі як:';